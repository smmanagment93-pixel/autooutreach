// Scans every connected Gmail account's Sent folder and cross-checks
// against the currently PENDING leads in the queue. Any pending lead whose
// email address is found in a Sent folder gets marked "sent" (without
// actually sending anything) — this catches leads that were already
// emailed outside this tool (manually, from a previous system, before this
// tool existed, etc.) so the automation never double-emails them.
//
// Trigger manually: GET/POST this function directly, or the Telegram
// /checksent command (see telegram-webhook.js) calls the same runCheckSent().

const { getConfig, getQueue, saveQueue } = require('../lib/store');
const { listSentRecipients } = require('../lib/gmail');
const { handlePreflight, withCors } = require('../lib/cors');

async function runCheckSent(accountIdFilter, customLimit) {
  const config = await getConfig();
  const queue = await getQueue();
  const pending = queue.filter((q) => q.status === 'pending');
  if (!pending.length) return { checked: 0, marked: 0, accountsScanned: 0, accountErrors: [], partialAccounts: [] };

  const accountsToScan = accountIdFilter
    ? (config.accounts || []).filter((a) => a.id === accountIdFilter)
    : config.accounts || [];

  let marked = 0;
  let accountsScanned = 0;
  const accountErrors = [];
  const partialAccounts = [];

  for (const acc of accountsToScan) {
    let sentSet, wasPartial;
    try {
      // Default cap is lower (2000) when scanning multiple accounts in one
      // run, to stay well within Netlify's ~10s function time limit.
      // Scanning a single account (via /checksent acc1) can afford to look
      // further back by default, or pass an explicit limit for very large
      // Sent histories (e.g. /checksent acc1 8000).
      const limit = customLimit || (accountIdFilter ? 6000 : 2000);
      const result = await listSentRecipients(acc.id, limit);
      sentSet = result.recipients;
      wasPartial = result.partial;
      if (wasPartial) partialAccounts.push(acc.id);
      accountsScanned++;
    } catch (e) {
      accountErrors.push(`${acc.id}: ${e.message}`);
      continue; // account not connected / IMAP error — skip, don't fail the whole run
    }
    for (const item of pending) {
      if (item.status !== 'pending') continue; // already matched by an earlier account this run
      if (sentSet.has((item.email || '').toLowerCase())) {
        item.status = 'sent';
        item.accountId = acc.id;
        item.sentAt = new Date().toISOString();
        item.lastActionAt = item.sentAt;
        item.note = 'Detected already in Sent folder — tool did not re-send';
        marked++;
      }
    }
  }

  await saveQueue(queue);
  return { checked: pending.length, marked, accountsScanned, accountErrors, partialAccounts };
}

exports.handler = async (event) => {
  const preflight = handlePreflight(event);
  if (preflight) return preflight;

  const params = event.queryStringParameters || {};
  const accountIdFilter = params.accountId || null;
  const customLimit = params.limit ? parseInt(params.limit, 10) : undefined;

  try {
    const result = await runCheckSent(accountIdFilter, customLimit);
    return withCors({
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(result),
    });
  } catch (e) {
    return withCors({
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: e.message }),
    });
  }
};

exports.runCheckSent = runCheckSent;
