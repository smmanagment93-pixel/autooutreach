// Scans a Gmail account's Sent folder for the last N days (default 15) and
// pulls any recipient NOT already in the queue into it — with the correct
// follow-up state already set (based on how many times they were actually
// emailed in that window). This is what makes "even manually-sent emails
// still get followed up" work: once imported, they're just a normal queue
// item and the regular process-queue cycle picks up their follow-ups like
// any other lead.
//
// Recipients whose LAST email in the window is older than `days` are
// skipped — the point is reviving only genuinely recent conversations, not
// dredging up everything ever sent.

const { getQueue, saveQueue } = require('../lib/store');
const { listRecentSentMessages } = require('../lib/gmail');
const { handlePreflight, withCors } = require('../lib/cors');

const MAX_FOLLOWUPS = 3;

async function runImportSentHistory(accountId, days = 15) {
  if (!accountId) throw new Error('accountId is required, e.g. /importsent acc1');

  const queue = await getQueue();
  const existingEmails = new Set(queue.map((q) => (q.email || '').toLowerCase()));

  const { byRecipient, partial } = await listRecentSentMessages(accountId, days);

  let imported = 0;
  let skippedExisting = 0;

  for (const [email, info] of byRecipient) {
    if (existingEmails.has(email)) {
      skippedExisting++;
      continue; // already tracked (either via tool or a previous import) — don't duplicate
    }
    const followUpsSent = Math.min(info.count - 1, MAX_FOLLOWUPS);
    const status = followUpsSent <= 0 ? 'sent' : `followup${followUpsSent}`;

    queue.push({
      id: email,
      email,
      name: info.name || email.split('@')[0],
      status,
      accountId,
      threadId: info.lastMessageId || null,
      sentAt: info.firstSentAt.toISOString(),
      lastActionAt: info.lastSentAt.toISOString(),
      followUpsSent,
      importedFromSentHistory: true,
      note: `Imported from Sent folder — ${info.count} email(s) found, manually sent outside the tool`,
    });
    existingEmails.add(email);
    imported++;
  }

  await saveQueue(queue);
  return { scanned: byRecipient.size, imported, skippedExisting, partial };
}

exports.handler = async (event) => {
  const preflight = handlePreflight(event);
  if (preflight) return preflight;

  const params = event.queryStringParameters || {};
  const accountId = params.accountId || null;
  const days = params.days ? parseInt(params.days, 10) : 15;

  try {
    const result = await runImportSentHistory(accountId, days);
    return withCors({
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(result),
    });
  } catch (e) {
    return withCors({
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: e.message }),
    });
  }
};

exports.runImportSentHistory = runImportSentHistory;
