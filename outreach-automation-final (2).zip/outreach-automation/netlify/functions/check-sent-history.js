// Scans every connected Gmail account's Sent folder and cross-checks
// against the currently PENDING leads in the queue. Any pending lead whose
// email address is found in a Sent folder gets marked with its REAL send
// history (actual date(s), how many times already emailed) instead of
// just "sent right now" — this matters because it's what lets the normal
// follow-up cascade pick up correctly (someone manually emailed 10 days
// ago is due for a follow-up now, not in another 2 days).
//
// Trigger manually: GET/POST this function directly, or the Telegram
// /checksent command (see telegram-webhook.js) calls the same runCheckSent().

const { getConfig, getQueue, saveQueue } = require('../lib/store');
const { listRecentSentMessages } = require('../lib/gmail');
const { handlePreflight, withCors } = require('../lib/cors');

const MAX_FOLLOWUPS = 3;

async function runCheckSent(accountIdFilter, customLimit) {
  const config = await getConfig();
  const queue = await getQueue();
  const pending = queue.filter((q) => q.status === 'pending');
  if (!pending.length) return { checked: 0, marked: 0, accountsScanned: 0, accountErrors: [], partialAccounts: [] };

  const accountsToScan = accountIdFilter
    ? (config.accounts || []).filter((a) => a.id === accountIdFilter)
    : config.accounts || [];

  let marked = 0;
  let accountsScanned = 0;
  const accountErrors = [];
  const partialAccounts = [];

  for (const acc of accountsToScan) {
    let byRecipient, wasPartial;
    try {
      // No day-limit here (unlike /importsent's 15-day window) — this is
      // about catching ANY already-contacted lead regardless of how long
      // ago, not just reviving recent conversations. `days` set high;
      // still time-budgeted so it can't overrun and get killed.
      const days = customLimit || 3650; // ~10 years — effectively "ever"
      const result = await listRecentSentMessages(acc.id, days);
      byRecipient = result.byRecipient;
      wasPartial = result.partial;
      if (wasPartial) partialAccounts.push(acc.id);
      accountsScanned++;
    } catch (e) {
      accountErrors.push(`${acc.id}: ${e.message}`);
      continue; // account not connected / IMAP error — skip, don't fail the whole run
    }
    for (const item of pending) {
      if (item.status !== 'pending') continue; // already matched by an earlier account this run
      const info = byRecipient.get((item.email || '').toLowerCase());
      if (!info) continue;

      const followUpsSent = Math.min(info.count - 1, MAX_FOLLOWUPS);
      item.status = followUpsSent <= 0 ? 'sent' : `followup${followUpsSent}`;
      item.accountId = acc.id;
      item.sentAt = info.firstSentAt.toISOString(); // real original send date, not "now"
      item.lastActionAt = info.lastSentAt.toISOString(); // real most-recent send date — follow-up gap counts from here, correctly
      item.followUpsSent = followUpsSent;
      item.threadId = info.lastMessageId || item.threadId;
      item.note = `Detected already in Sent folder (${info.count} email(s) found) — tool did not re-send`;
      marked++;
    }
  }

  await saveQueue(queue);
  return { checked: pending.length, marked, accountsScanned, accountErrors, partialAccounts };
}

exports.handler = async (event) => {
  const preflight = handlePreflight(event);
  if (preflight) return preflight;

  const params = event.queryStringParameters || {};
  const accountIdFilter = params.accountId || null;
  const customLimit = params.limit ? parseInt(params.limit, 10) : undefined;

  try {
    const result = await runCheckSent(accountIdFilter, customLimit);
    return withCors({
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(result),
    });
  } catch (e) {
    return withCors({
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: e.message }),
    });
  }
};

exports.runCheckSent = runCheckSent;
