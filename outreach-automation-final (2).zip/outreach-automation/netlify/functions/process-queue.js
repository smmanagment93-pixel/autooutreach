const { schedule } = require('@netlify/functions');
const { getConfig, getQueue, saveQueue } = require('../lib/store');
const { sendMail, getReplyDetails } = require('../lib/gmail');
const { composeFirstEmail, composeFollowUp } = require('../lib/compose');
const { notifyTelegram } = require('../lib/notify');
const { pickSmartHour } = require('../lib/timing');

const MAX_FOLLOWUPS = 3;
const REPLY_RECHECK_HOURS = 3;

// Netlify's free-tier function execution limits are MUCH shorter than they
// look at first: regular functions get ~10s, and even *scheduled* functions
// (like this one) only get ~30s — nowhere near enough to safely send 18
// emails with human-like delays between them. Blowing past that limit gets
// the function killed mid-work, which is what caused duplicate sends (an
// email could go out via SMTP, then get killed before its "sent" status
// was saved, so a later run saw it as still pending and re-sent it) and a
// frozen-looking Telegram bot (Telegram retries a webhook that never
// responded in time, so /run kept re-triggering instead of new commands
// being processed).
//
// The fix: instead of trying to guess a safe fixed batch size, this run
// tracks its own elapsed time and stops picking up NEW work well before
// any Netlify limit could kill it — whether it's invoked by the schedule,
// by /run, or by the run-now.js URL, all of which have different (short)
// time budgets. netlify.toml runs this every few minutes instead of every
// 20, so small-but-frequent cycles still add up to the daily volume.
const RUN_TIME_BUDGET_MS = 8000; // safe even under the tightest (10s) limit
const RUN_STARTED_AT = Date.now();
function timeLeft() {
  return RUN_TIME_BUDGET_MS - (Date.now() - RUN_STARTED_AT);
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function daysSince(iso) {
  if (!iso) return Infinity;
  return (Date.now() - new Date(iso).getTime()) / 86400000;
}
function hoursSince(iso) {
  if (!iso) return Infinity;
  return (Date.now() - new Date(iso).getTime()) / 3600000;
}
function isToday(iso) {
  if (!iso) return false;
  return new Date(iso).toDateString() === new Date().toDateString();
}
function truncate(s, n) {
  return s.length > n ? s.slice(0, n) + '…' : s;
}
function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// Returns current time in IST (Asia/Kolkata) as "HH:MM", regardless of the
// server's own timezone (Netlify functions run in UTC).
function nowIST() {
  return new Date().toLocaleTimeString('en-GB', {
    timeZone: 'Asia/Kolkata',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }); // e.g. "17:34"
}

// config.sendWindowStart / sendWindowEnd are "HH:MM" strings in IST, or
// null/empty to mean "no restriction — send anytime, 24x7" (default,
// backward-compatible with setups that never configured a window).
// Handles overnight windows too (e.g. start "22:00" end "06:00").
function isWithinSendWindow(config) {
  const start = config.sendWindowStart;
  const end = config.sendWindowEnd;
  if (!start || !end) return true; // no window configured = always allowed
  const now = nowIST();
  if (start <= end) {
    return now >= start && now <= end;
  }
  // overnight window, e.g. 22:00 -> 06:00
  return now >= start || now <= end;
}

function currentHourIST() {
  return parseInt(new Date().toLocaleTimeString('en-GB', { timeZone: 'Asia/Kolkata', hour: '2-digit', hour12: false }), 10);
}

// Hour bounds used for picking a natural-feeling, varied follow-up time
// (morning/afternoon/evening). Falls back to a sensible 8am-8pm default
// when no explicit /setwindow is configured, rather than allowing a
// "smart" hour to land at 3am.
function followUpHourBounds(config) {
  const parseHour = (s) => (s ? parseInt(s.split(':')[0], 10) : null);
  const startH = parseHour(config.sendWindowStart);
  const endH = parseHour(config.sendWindowEnd);
  if (startH === null || endH === null) return { startH: 8, endH: 20 };
  return { startH, endH };
}

async function runOnce() {
  const config = await getConfig();
  if (process.env.AUTOMATION_ENABLED === 'false' || config.automationPaused) {
    return { skipped: true, reason: config.automationPaused ? 'paused via Telegram' : 'AUTOMATION_ENABLED=false' };
  }
  const queue = await getQueue();
  const accountsById = Object.fromEntries((config.accounts || []).map((a) => [a.id, a]));

  // ---- 1. Check for replies (auto-stop sequence when a lead replies) ----
  // Budgeted: leaves at least 4s free for the sending phase below, and
  // bails out of the reply-check loop the moment that budget is gone.
  let checked = 0;
  const newReplies = [];
  for (const item of queue) {
    if (timeLeft() < 4000) break; // leave room for at least one send attempt
    if (item.status === 'replied' || item.status === 'pending') continue;
    if (!item.threadId || !item.accountId) continue;
    if (hoursSince(item.lastCheckedAt) < REPLY_RECHECK_HOURS) continue;
    const acc = accountsById[item.accountId];
    if (!acc) continue;
    checked++;
    try {
      const details = await getReplyDetails(item.accountId, item.threadId, acc.email);
      item.lastCheckedAt = new Date().toISOString();
      if (details.replied) {
        item.status = 'replied'; // excluded from dueForFollowUp below — sequence stops for good
        item.repliedAt = item.repliedAt || new Date().toISOString();
        item.replySnippet = details.snippet || '';
        item.replyFrom = details.from || '';
        newReplies.push(item);
      }
    } catch (e) {
      item.lastCheckError = e.message;
    }
  }
  if (checked > 0) await saveQueue(queue); // persist reply-check progress even if send phase gets skipped

  // ---- 2. Figure out how much headroom each account has today ----
  const sentTodayByAccount = {};
  for (const a of config.accounts || []) {
    sentTodayByAccount[a.id] = queue.filter((q) => q.accountId === a.id && q.sentAt && isToday(q.sentAt)).length;
  }
  const totalSentToday = Object.values(sentTodayByAccount).reduce((s, n) => s + n, 0);
  let dailyTargetRemaining = (config.dailyTarget || 500) - totalSentToday;

  function accountWithRoom() {
    const candidates = (config.accounts || [])
      .filter((a) => sentTodayByAccount[a.id] < (a.dailyCap || 0))
      .sort((a, b) => sentTodayByAccount[a.id] - sentTodayByAccount[b.id]);
    return candidates[0] || null;
  }

  // ---- 2.5. Concurrency safety: skip items another run is mid-send on ----
  // Before sending, each item gets `claimedAt` set + saved immediately (see
  // below) so a second overlapping run (scheduled cron firing while a
  // manual /run is still going, or two /run's back-to-back) sees the claim
  // and skips it instead of emailing the same lead twice. If a run crashes
  // mid-send, the claim goes stale after CLAIM_STUCK_MS and is released so
  // the lead isn't stuck forever.
  const CLAIM_STUCK_MS = 3 * 60 * 1000; // 3 minutes
  for (const q of queue) {
    if (q.claimedAt && Date.now() - new Date(q.claimedAt).getTime() > CLAIM_STUCK_MS) {
      q.claimedAt = null; // stale — release so it can be retried
    }
  }

  // ---- 3. Build the list of leads due for action right now ----
  const withinWindow = isWithinSendWindow(config);
  const followUpGapDays = config.followUpGapDays || 2;
  const { startH: fuStartH, endH: fuEndH } = followUpHourBounds(config);
  const curHourIST = currentHourIST();
  const dueForFirstSend = withinWindow ? queue.filter((q) => q.status === 'pending' && !q.claimedAt) : [];
  const dueForFollowUp = withinWindow
    ? queue.filter((q) => {
        if (!['sent', 'followup1', 'followup2'].includes(q.status)) return false;
        if ((q.followUpsSent || 0) >= MAX_FOLLOWUPS) return false;
        if (daysSince(q.lastActionAt) < followUpGapDays) return false;
        if (q.claimedAt) return false;
        // Each lead gets its own randomized/reply-rate-biased target hour
        // (assigned right after its previous send — see below) so
        // follow-ups naturally land kabhi subah, kabhi dopahar, kabhi
        // shaam instead of always firing at the exact same clock time.
        // Older items from before this feature existed won't have this
        // field yet — those just go out as soon as the day-gap is met.
        if (typeof q.nextActionHourIST === 'number') {
          const diff = Math.min(
            Math.abs(curHourIST - q.nextActionHourIST),
            24 - Math.abs(curHourIST - q.nextActionHourIST)
          );
          if (diff > 1) return false; // not this lead's hour yet
        }
        return true;
      })
    : [];

  let sentCount = 0,
    firstSendCount = 0,
    followUpCount = 0,
    failCount = 0;

  // Follow-ups first — these have a deadline (2-day cadence), new leads don't.
  for (const item of [...dueForFollowUp, ...dueForFirstSend]) {
    if (timeLeft() < 3000) break; // not enough budget left to safely start (and save) another send
    if (dailyTargetRemaining <= 0) break;

    const isFollowUp = item.status !== 'pending';
    let account;
    if (isFollowUp) {
      // Must reply from the SAME mailbox the thread started in.
      account = accountsById[item.accountId];
      if (!account || sentTodayByAccount[account.id] >= (account.dailyCap || 0)) continue;
    } else {
      account = accountWithRoom();
      if (!account) continue;
    }

    // Claim this item and persist IMMEDIATELY, before actually sending —
    // this is what stops a second overlapping run from also picking it up.
    item.claimedAt = new Date().toISOString();
    await saveQueue(queue);

    try {
      const followUpNumber = (item.followUpsSent || 0) + 1;
      const { subject, body } = isFollowUp
        ? await composeFollowUp(item, config, followUpNumber)
        : await composeFirstEmail(item, config);

      // Safety net: never actually send a blank/near-blank email. If this
      // ever fires it means something upstream (AI, template) broke —
      // better to skip and retry next run than send an empty message.
      if (!subject || !subject.trim() || !body || body.trim().length < 20) {
        throw new Error('Composed email was empty/too short — skipped instead of sending blank.');
      }

      const result = await sendMail(account.id, account.email, {
        to: item.email,
        subject,
        body,
        threadId: isFollowUp ? item.threadId : undefined,
      });

      item.accountId = account.id;
      item.threadId = result.threadId;
      item.lastActionAt = new Date().toISOString();
      if (!isFollowUp) {
        item.status = 'sent';
        item.sentAt = item.lastActionAt;
        firstSendCount++;
      } else {
        item.followUpsSent = followUpNumber;
        item.status = `followup${followUpNumber}`;
        followUpCount++;
      }
      // Pick when (which hour, IST) the NEXT follow-up should fire —
      // biased toward historically better reply-rate hours once there's
      // enough data, otherwise a plain varied random hour within the
      // window. Harmless to set even on the 3rd follow-up (simply unused
      // since MAX_FOLLOWUPS stops it from being picked up again).
      item.nextActionHourIST = pickSmartHour(queue, fuStartH, fuEndH);

      sentTodayByAccount[account.id] = (sentTodayByAccount[account.id] || 0) + 1;
      dailyTargetRemaining--;
      sentCount++;
    } catch (e) {
      item.failCount = (item.failCount || 0) + 1;
      item.lastError = e.message;
      failCount++;
    }

    item.claimedAt = null; // release the claim — done (sent or failed either way)
    await saveQueue(queue); // save right after each send, not just at the very end —
    // so a crash/timeout mid-run never loses track of emails already sent

    // Small, cheap pause between sends — NOT the old 4-12s "human-like"
    // delay (there's no time budget left for that anymore). Natural
    // spacing now comes from running this cycle every few minutes instead
    // of every 20, rather than from padding inside a single run.
    if (timeLeft() > 3500) await sleep(400 + Math.random() * 600);
  }

  await saveQueue(queue);

  // ---- 4. Telegram update — only when something actually happened ----
  if (firstSendCount || followUpCount || newReplies.length || failCount) {
    const lines = ['📬 <b>Outreach Hub update</b>'];
    if (firstSendCount) lines.push(`✅ ${firstSendCount} naye email bheje gaye`);
    if (followUpCount) lines.push(`🔁 ${followUpCount} follow-up bheje gaye`);
    if (failCount) lines.push(`⚠️ ${failCount} bhejne mein fail hui`);
    if (newReplies.length) {
      lines.push(`💬 <b>${newReplies.length} naya reply aaya!</b> Sequence auto-stop ho gaya:`);
      for (const r of newReplies.slice(0, 8)) {
        lines.push(`\n• <b>${escapeHtml(r.name || r.email)}</b> (${escapeHtml(r.email)})`);
        if (r.channelLink) lines.push(`  🔗 ${escapeHtml(r.channelLink)}`);
        if (r.replySnippet) lines.push(`  💬 "${escapeHtml(truncate(r.replySnippet, 200))}"`);
      }
      if (newReplies.length > 8) lines.push(`\n...aur ${newReplies.length - 8} aur (dashboard/status check karo)`);
    }
    await notifyTelegram(lines.join('\n'));
  }

  return {
    sentCount,
    firstSendCount,
    followUpCount,
    failCount,
    newReplies: newReplies.length,
    repliesChecked: checked,
    withinSendWindow: withinWindow,
    elapsedMs: Date.now() - RUN_STARTED_AT,
  };
}

exports.handler = schedule('*/3 * * * *', async () => {
  const result = await runOnce();
  console.log('process-queue run:', JSON.stringify(result));
  return { statusCode: 200 };
});

// Also exported so it can be hit manually (e.g. a "Run now" button, or
// curl'd right after deploy to sanity-check everything works) without
// waiting up to 20 minutes for the schedule to fire.
exports.runOnce = runOnce;
